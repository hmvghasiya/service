@if(isset($data))
<p>Address : {{$data->address}}</p>
<p>City : {{$data->city}}</p>
<p>State : {{$data->state}}</p>
@endif