@if(isset($data))
<p>Address : {{$data->full_address}}</p>
{{-- <p>City : {{$data->city}}</p> --}}
{{-- <p>State : {{$data->state}}</p> --}}
@endif